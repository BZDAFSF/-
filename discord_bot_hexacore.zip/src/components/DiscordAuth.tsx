import { useState, useEffect } from "react";
import { useAction } from "convex/react";
import { api } from "../../convex/_generated/api";

export function DiscordAuth() {
  const [isLoading, setIsLoading] = useState(false);
  const getAuthUrl = useAction(api.authDiscord.getDiscordAuthUrl);
  const exchangeCode = useAction(api.authDiscord.exchangeDiscordCode);

  useEffect(() => {
    // Check if we have a code in the URL (callback from Discord)
    const urlParams = new URLSearchParams(window.location.search);
    const code = urlParams.get('code');
    
    if (code) {
      handleDiscordCallback(code);
    }
  }, []);

  const handleDiscordCallback = async (code: string) => {
    setIsLoading(true);
    try {
      const result = await exchangeCode({ code });
      console.log('Discord auth successful:', result);
      
      // Store user data and redirect to dashboard
      localStorage.setItem('discordUser', JSON.stringify(result.user));
      localStorage.setItem('discordGuilds', JSON.stringify(result.guilds));
      
      // Remove code from URL
      window.history.replaceState({}, document.title, window.location.pathname);
      
      // Refresh page to show dashboard
      window.location.reload();
    } catch (error) {
      console.error('Discord auth failed:', error);
      alert('Authentication failed. Please try again.');
    } finally {
      setIsLoading(false);
    }
  };

  const handleDiscordLogin = async () => {
    setIsLoading(true);
    try {
      const authUrl = await getAuthUrl();
      window.location.href = authUrl;
    } catch (error) {
      console.error('Failed to get auth URL:', error);
      setIsLoading(false);
    }
  };

  if (isLoading) {
    return (
      <div className="flex items-center justify-center min-h-screen bg-gradient-to-br from-gray-900 via-orange-900 to-black">
        <div className="text-center">
          <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-orange-500 mx-auto mb-4"></div>
          <p className="text-orange-400">Authenticating with Discord...</p>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gradient-to-br from-gray-900 via-orange-900 to-black flex items-center justify-center">
      <div className="w-full max-w-md">
        <div className="text-center mb-8">
          <h1 className="text-4xl font-bold bg-gradient-to-r from-orange-400 to-red-500 bg-clip-text text-transparent mb-2">
            𝐇𝐞𝐱𝐚𝐂𝐨𝐫𝐞
          </h1>
          <p className="text-gray-400">Advanced Discord Bot Dashboard</p>
        </div>
        
        <div className="bg-black/40 backdrop-blur-sm border border-orange-500/30 rounded-xl p-8">
          <h2 className="text-2xl font-bold text-orange-400 mb-6 text-center">Login to Dashboard</h2>
          
          <button
            onClick={handleDiscordLogin}
            disabled={isLoading}
            className="w-full bg-[#5865F2] hover:bg-[#4752C4] text-white font-semibold py-3 px-4 rounded-lg transition-all duration-200 flex items-center justify-center space-x-3 disabled:opacity-50"
          >
            <svg className="w-6 h-6" viewBox="0 0 24 24" fill="currentColor">
              <path d="M20.317 4.37a19.791 19.791 0 0 0-4.885-1.515a.074.074 0 0 0-.079.037c-.21.375-.444.864-.608 1.25a18.27 18.27 0 0 0-5.487 0a12.64 12.64 0 0 0-.617-1.25a.077.077 0 0 0-.079-.037A19.736 19.736 0 0 0 3.677 4.37a.07.07 0 0 0-.032.027C.533 9.046-.32 13.58.099 18.057a.082.082 0 0 0 .031.057a19.9 19.9 0 0 0 5.993 3.03a.078.078 0 0 0 .084-.028a14.09 14.09 0 0 0 1.226-1.994a.076.076 0 0 0-.041-.106a13.107 13.107 0 0 1-1.872-.892a.077.077 0 0 1-.008-.128a10.2 10.2 0 0 0 .372-.292a.074.074 0 0 1 .077-.01c3.928 1.793 8.18 1.793 12.062 0a.074.074 0 0 1 .078.01c.12.098.246.198.373.292a.077.077 0 0 1-.006.127a12.299 12.299 0 0 1-1.873.892a.077.077 0 0 0-.041.107c.36.698.772 1.362 1.225 1.993a.076.076 0 0 0 .084.028a19.839 19.839 0 0 0 6.002-3.03a.077.077 0 0 0 .032-.054c.5-5.177-.838-9.674-3.549-13.66a.061.061 0 0 0-.031-.03zM8.02 15.33c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.956-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.956 2.418-2.157 2.418zm7.975 0c-1.183 0-2.157-1.085-2.157-2.419c0-1.333.955-2.419 2.157-2.419c1.21 0 2.176 1.096 2.157 2.42c0 1.333-.946 2.418-2.157 2.418z"/>
            </svg>
            <span>Login with Discord</span>
          </button>
          
          <div className="mt-6 text-center text-sm text-gray-400">
            <p>By logging in, you agree to our Terms of Service</p>
            <p className="mt-2">We only access basic profile information and your servers</p>
          </div>
        </div>
        
        <div className="mt-8 text-center">
          <div className="grid grid-cols-2 gap-4 text-sm">
            <div className="bg-black/20 backdrop-blur-sm border border-orange-500/20 rounded-lg p-4">
              <div className="text-2xl mb-2">🛡️</div>
              <div className="text-orange-400 font-semibold">Advanced Moderation</div>
              <div className="text-gray-400">Auto-mod, logging, templates</div>
            </div>
            <div className="bg-black/20 backdrop-blur-sm border border-orange-500/20 rounded-lg p-4">
              <div className="text-2xl mb-2">🎵</div>
              <div className="text-purple-400 font-semibold">Music Player</div>
              <div className="text-gray-400">YouTube, Spotify, Quran</div>
            </div>
            <div className="bg-black/20 backdrop-blur-sm border border-orange-500/20 rounded-lg p-4">
              <div className="text-2xl mb-2">🎮</div>
              <div className="text-green-400 font-semibold">100+ Games</div>
              <div className="text-gray-400">Trivia, mini-games, anime</div>
            </div>
            <div className="bg-black/20 backdrop-blur-sm border border-orange-500/20 rounded-lg p-4">
              <div className="text-2xl mb-2">🤖</div>
              <div className="text-blue-400 font-semibold">AI Features</div>
              <div className="text-gray-400">Chat, images, code, OCR</div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}
